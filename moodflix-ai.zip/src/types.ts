export interface Movie {
  id: string;
  tmdbId: number;
  movieLensId?: number;
  title: string;
  originalTitle?: string;
  year: number;
  genres: string[];
  runtime: string;
  rating: number; // e.g. 8.6
  voteCount?: number;
  posterUrl: string;
  backdropUrl: string;
  overview: string;
  director: string;
  cast: string[];
  keywords: string[];
  budget?: number;
  revenue?: number;
  originalLanguage: string; // e.g. 'en', 'ja', 'hi', 'ko', 'fr', 'es'
  descriptionStatus: 'complete' | 'fallback_english' | 'incomplete';
  contentHash?: string;
  moodTags: string[];
  aestheticAttributes: {
    cinematography: string;
    pace: 'Slow & Meditative' | 'Moderate' | 'Fast & Energetic';
    tone: string;
    music: string;
  };
  popularityScore: number;
  vectorEmbedding?: number[];
}

export interface User {
  id: string;
  email: string;
  displayName: string;
  avatarUrl: string;
  subscriptionTier: 'free' | 'premium' | 'pro_cinematic';
  role: 'user' | 'admin';
  onboardingCompleted: boolean;
  emailVerified: boolean;
  createdAt: string;
  lastLoginAt: string;
}

export interface UserPreferences {
  userId: string;
  favoriteGenres: string[];
  dislikedGenres: string[];
  preferredLanguages: string[]; // e.g. ["en", "ja", "ko", "hi", "fr"]
  preferredDecadeRange: string;
  contentRatingLimit: string;
  favoriteActorsOrDirectors: string[];
  viewingGoal: string; // 'relax' | 'discover' | 'rewatch'
  onboardingCompleted: boolean;
  role: 'user' | 'admin';
  adminCatalogRegionFocus?: string;
}

export interface AuthState {
  user: User | null;
  accessToken: string | null;
  isAuthenticated: boolean;
}

export interface MoodProfile {
  primaryEmotion: string;
  secondaryEmotions: string[];
  cortisolMarker: 'High' | 'Moderate' | 'Low' | 'Restorative';
  valence: number; // -1.0 to 1.0
  energyLevel: number; // 0.0 to 1.0
  stressLevel: number; // 0.0 to 1.0
  psychologicalNeed: string;
}

export interface Recommendation {
  movie: Movie;
  matchPercentage: number; // e.g. 98
  confidenceScore: number; // e.g. 0.942
  reasoning: {
    whyThisMovie: string; // Natural language explanation based on deep plot, keywords, and language context
    moodProfileTags: string[];
    aestheticSyncScore: number; // e.g. 91
    vectorSimilarityDistance: number; // e.g. 0.142
    highlightedKeywords: string[];
    languageMatchNote?: string;
  };
  scoreBreakdown: {
    moodMatch: number;
    semanticSimilarity: number;
    contentGenreScore: number;
    userRatingScore: number;
    popularityWeight: number;
  };
}

export interface WatchHistoryItem {
  id: string;
  userId: string;
  movie: Movie;
  watchedAt: string;
  userMoodPrompt: string;
  userRating?: number;
}

export interface SRSSection {
  id: string;
  title: string;
  subtitle: string;
  content: string;
  subsections?: {
    title: string;
    content: string;
    codeSnippet?: string;
  }[];
}

export interface IngestionJobStats {
  totalProcessed: number;
  embeddingsGenerated: number;
  cachedEmbeddingsReused: number;
  rateLimitBackoffsTriggered: number;
  incompleteDescriptionsCount: number;
  lastSyncTimestamp: string;
}
