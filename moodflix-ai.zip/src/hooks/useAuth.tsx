import React, { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { User, UserPreferences } from '../types';

interface AuthContextType {
  user: User | null;
  preferences: UserPreferences | null;
  isAuthenticated: boolean;
  accessToken: string | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (email: string, password: string, displayName: string) => Promise<{ success: boolean; error?: string }>;
  googleSignIn: (idToken: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  openAuthModal: (mode?: 'login' | 'register') => void;
  closeAuthModal: () => void;
  isAuthModalOpen: boolean;
  authModalMode: 'login' | 'register';
  isOnboardingOpen: boolean;
  openOnboardingModal: () => void;
  closeOnboardingModal: () => void;
  submitOnboarding: (data: Partial<UserPreferences>) => Promise<boolean>;
  updatePreferences: (data: Partial<UserPreferences>) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [preferences, setPreferences] = useState<UserPreferences | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');
  const [isOnboardingOpen, setIsOnboardingOpen] = useState<boolean>(false);

  const fetchUserPreferences = async (userId: string) => {
    try {
      const res = await fetch(`/api/users/me/preferences?userId=${userId}`);
      if (res.ok) {
        const prefs = await res.json();
        setPreferences(prefs);
      }
    } catch (err) {
      console.error('Failed to fetch user preferences:', err);
    }
  };

  // Load session on startup
  useEffect(() => {
    const initAuth = async () => {
      try {
        const storedToken = sessionStorage.getItem('moodflix_at');
        if (storedToken) {
          const res = await fetch('/api/auth/me', {
            headers: { Authorization: `Bearer ${storedToken}` },
          });
          if (res.ok) {
            const data = await res.json();
            setUser(data.user);
            setAccessToken(storedToken);
            await fetchUserPreferences(data.user.id);

            if (!data.user.onboardingCompleted) {
              setIsOnboardingOpen(true);
            }
          } else {
            sessionStorage.removeItem('moodflix_at');
          }
        }
      } catch (err) {
        console.error('Failed to restore auth session:', err);
      } finally {
        setIsLoading(false);
      }
    };
    initAuth();
  }, []);

  const login = async (email: string, password: string) => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();

      if (!res.ok) {
        return { success: false, error: data.error || 'Login failed' };
      }

      setUser(data.user);
      setAccessToken(data.accessToken);
      sessionStorage.setItem('moodflix_at', data.accessToken);
      setIsAuthModalOpen(false);

      await fetchUserPreferences(data.user.id);

      if (!data.user.onboardingCompleted) {
        setIsOnboardingOpen(true);
      }

      return { success: true };
    } catch (err) {
      return { success: false, error: 'Network error during login' };
    }
  };

  const register = async (email: string, password: string, displayName: string) => {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, displayName }),
      });
      const data = await res.json();

      if (!res.ok) {
        return { success: false, error: data.error || 'Registration failed' };
      }

      setUser(data.user);
      setAccessToken(data.accessToken);
      sessionStorage.setItem('moodflix_at', data.accessToken);
      setIsAuthModalOpen(false);

      await fetchUserPreferences(data.user.id);
      setIsOnboardingOpen(true);

      return { success: true };
    } catch (err) {
      return { success: false, error: 'Network error during registration' };
    }
  };

  const googleSignIn = async (idToken: string) => {
    try {
      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken }),
      });
      const data = await res.json();

      if (!res.ok) {
        return { success: false, error: data.error || 'Google sign-in failed' };
      }

      setUser(data.user);
      setAccessToken(data.accessToken);
      sessionStorage.setItem('moodflix_at', data.accessToken);
      setIsAuthModalOpen(false);

      await fetchUserPreferences(data.user.id);

      if (!data.user.onboardingCompleted) {
        setIsOnboardingOpen(true);
      }

      return { success: true };
    } catch (err) {
      return { success: false, error: 'Google sign-in error' };
    }
  };

  const logout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      setUser(null);
      setPreferences(null);
      setAccessToken(null);
      sessionStorage.removeItem('moodflix_at');
    }
  };

  const submitOnboarding = async (data: Partial<UserPreferences>) => {
    try {
      const res = await fetch('/api/users/me/onboarding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...data, userId: user?.id }),
      });
      const result = await res.json();
      if (res.ok) {
        setPreferences(result.preferences);
        if (user) {
          setUser({ ...user, onboardingCompleted: true });
        }
        setIsOnboardingOpen(false);
        return true;
      }
      return false;
    } catch (err) {
      console.error('Failed to submit onboarding:', err);
      return false;
    }
  };

  const updatePreferences = async (data: Partial<UserPreferences>) => {
    try {
      const res = await fetch('/api/users/me/preferences', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...data, userId: user?.id }),
      });
      const result = await res.json();
      if (res.ok) {
        setPreferences(result.preferences);
        return true;
      }
      return false;
    } catch (err) {
      console.error('Failed to update preferences:', err);
      return false;
    }
  };

  const openAuthModal = (mode: 'login' | 'register' = 'login') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  const openOnboardingModal = () => {
    setIsOnboardingOpen(true);
  };

  const closeOnboardingModal = () => {
    setIsOnboardingOpen(false);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        preferences,
        isAuthenticated: Boolean(user),
        accessToken,
        isLoading,
        login,
        register,
        googleSignIn,
        logout,
        openAuthModal,
        closeAuthModal,
        isAuthModalOpen,
        authModalMode,
        isOnboardingOpen,
        openOnboardingModal,
        closeOnboardingModal,
        submitOnboarding,
        updatePreferences,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
