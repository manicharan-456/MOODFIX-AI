import { Movie, IngestionJobStats } from '../types';
import { MOVIES_DATABASE } from './movies';

/**
 * Calculates a content hash from a movie's plot, keywords, and genres.
 * Used for incremental embedding checks to ensure we never re-embed unchanged movies.
 */
export function calculateContentHash(overview: string, keywords: string[], genres: string[]): string {
  const text = `${overview}|${keywords.sort().join(',')}|${genres.sort().join(',')}`;
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    const char = text.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32bit integer
  }
  return `hash_${Math.abs(hash).toString(16)}`;
}

/**
 * Simulates the offline MovieLens + TMDB background batch ingestion worker.
 * Reads raw MovieLens mapping (links.csv), fetches full TMDB metadata with backoff,
 * checks content hashes, and updates vector embeddings incrementally.
 */
export async function runIngestionPipelineBatch(): Promise<{
  updatedMovies: Movie[];
  stats: IngestionJobStats;
}> {
  console.log('[Ingestion Pipeline] Starting MovieLens + TMDB batch ingestion worker...');
  
  let embeddingsGenerated = 0;
  let cachedEmbeddingsReused = 0;
  let rateLimitBackoffsTriggered = 0;

  const processedMovies: Movie[] = MOVIES_DATABASE.map((movie) => {
    const currentHash = calculateContentHash(movie.overview, movie.keywords || [], movie.genres);
    
    if (movie.contentHash && movie.contentHash === currentHash && movie.vectorEmbedding) {
      // Content hash matches: reuse cached FAISS vector
      cachedEmbeddingsReused++;
      return movie;
    }

    // New or modified content: trigger SentenceTransformers all-MiniLM-L6-v2 vector generation
    embeddingsGenerated++;
    
    // Simulate backoff check for high load
    if (embeddingsGenerated % 4 === 0) {
      rateLimitBackoffsTriggered++;
    }

    // Generate mock 384-dimensional vector slice representation
    const mockVector = Array.from({ length: 10 }, (_, i) => 
      Number((Math.sin(movie.tmdbId + i) * 0.5).toFixed(3))
    );

    return {
      ...movie,
      contentHash: currentHash,
      vectorEmbedding: mockVector,
    };
  });

  const stats: IngestionJobStats = {
    totalProcessed: processedMovies.length,
    embeddingsGenerated,
    cachedEmbeddingsReused,
    rateLimitBackoffsTriggered,
    incompleteDescriptionsCount: processedMovies.filter((m) => m.descriptionStatus === 'incomplete' || !m.overview || m.overview.trim() === '').length,
    lastSyncTimestamp: new Date().toISOString(),
  };

  console.log('[Ingestion Pipeline] Ingestion complete:', stats);
  return { updatedMovies: processedMovies, stats };
}
