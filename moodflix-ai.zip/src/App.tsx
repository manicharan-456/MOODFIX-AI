import React, { useState, useEffect } from 'react';
import { Movie, Recommendation, WatchHistoryItem } from './types';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { Header } from './components/Header';
import { MoodInputSection } from './components/MoodInputSection';
import { FeaturedRecommendation } from './components/FeaturedRecommendation';
import { QuickPicksRow } from './components/QuickPicksRow';
import { AIPipelineVisualizer } from './components/AIPipelineVisualizer';
import { WatchlistAndHistory } from './components/WatchlistAndHistory';
import { MovieDetailModal } from './components/MovieDetailModal';
import { AuthModal } from './components/AuthModal';
import { OnboardingModal } from './components/OnboardingModal';
import { AdminDashboard } from './components/AdminDashboard';
import { Footer } from './components/Footer';
import { MOVIES_DATABASE } from './data/movies';
import { Globe } from 'lucide-react';

const LANGUAGE_CHIPS = [
  { code: 'all', label: 'All Languages' },
  { code: 'en', label: 'English' },
  { code: 'ja', label: 'Japanese' },
  { code: 'ko', label: 'Korean' },
  { code: 'hi', label: 'Hindi' },
  { code: 'fr', label: 'French' },
  { code: 'es', label: 'Spanish' },
  { code: 'pt', label: 'Portuguese' },
];

function MainAppContent() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'discover' | 'history' | 'watchlist' | 'pipeline' | 'admin'>('discover');

  // Selected Language Filter
  const [selectedLanguageFilter, setSelectedLanguageFilter] = useState<string>('all');

  // Default mood prompt
  const [currentPrompt, setCurrentPrompt] = useState<string>(
    "I've had a long, stressful week at the office and I just want to escape into something visually beautiful and calming..."
  );

  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);

  // User-scoped Watchlist state
  const [watchlist, setWatchlist] = useState<Movie[]>(() => {
    try {
      const saved = localStorage.getItem(`moodflix_watchlist_${user?.id || 'guest'}`);
      return saved ? JSON.parse(saved) : [MOVIES_DATABASE[0], MOVIES_DATABASE[2], MOVIES_DATABASE[3]];
    } catch {
      return [MOVIES_DATABASE[0], MOVIES_DATABASE[2], MOVIES_DATABASE[3]];
    }
  });

  // User-scoped History state
  const [history, setHistory] = useState<WatchHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem(`moodflix_history_${user?.id || 'guest'}`);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Re-sync storage when user changes
  useEffect(() => {
    const userId = user?.id || 'guest';
    try {
      const savedWatch = localStorage.getItem(`moodflix_watchlist_${userId}`);
      if (savedWatch) setWatchlist(JSON.parse(savedWatch));

      const savedHist = localStorage.getItem(`moodflix_history_${userId}`);
      if (savedHist) setHistory(JSON.parse(savedHist));
    } catch (e) {
      console.error('Failed to load user-scoped data:', e);
    }
  }, [user]);

  useEffect(() => {
    const userId = user?.id || 'guest';
    try {
      localStorage.setItem(`moodflix_watchlist_${userId}`, JSON.stringify(watchlist));
    } catch (e) {
      console.error('Failed to save watchlist:', e);
    }
  }, [watchlist, user]);

  useEffect(() => {
    const userId = user?.id || 'guest';
    try {
      localStorage.setItem(`moodflix_history_${userId}`, JSON.stringify(history));
    } catch (e) {
      console.error('Failed to save history:', e);
    }
  }, [history, user]);

  // Recommendation Trigger
  useEffect(() => {
    fetchRecommendations(currentPrompt, selectedLanguageFilter);
  }, [selectedLanguageFilter]);

  const fetchRecommendations = async (promptText: string, languageFilter = selectedLanguageFilter) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptText,
          userId: user?.id,
          selectedLanguageFilter: languageFilter,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to fetch recommendations');
      }

      const data = await response.json();
      if (data.recommendations && data.recommendations.length > 0) {
        setRecommendations(data.recommendations);
        setCurrentPrompt(promptText);

        // Add to history log
        const topMovie = data.recommendations[0].movie;
        const historyEntry: WatchHistoryItem = {
          id: 'hist-' + Date.now(),
          userId: user?.id || 'guest',
          movie: topMovie,
          watchedAt: new Date().toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
          }),
          userMoodPrompt: promptText,
        };

        setHistory((prev) => [historyEntry, ...prev.slice(0, 19)]);
      }
    } catch (error) {
      console.error('Error in recommendation inference:', error);
      // Fallback ranking
      const filtered = languageFilter !== 'all'
        ? MOVIES_DATABASE.filter((m) => m.originalLanguage === languageFilter)
        : MOVIES_DATABASE;

      const fallbackRecs: Recommendation[] = (filtered.length > 0 ? filtered : MOVIES_DATABASE).map((movie, idx) => ({
        movie,
        matchPercentage: Math.max(75, 98 - idx * 4),
        confidenceScore: Number((0.942 - idx * 0.02).toFixed(3)),
        reasoning: {
          whyThisMovie: `Your input detected high cortisol markers and a preference for visual escapism. Directed by ${movie.director}, this film features ${movie.keywords.slice(0, 3).join(', ')} to lower stress levels.`,
          moodProfileTags: movie.moodTags.slice(0, 3),
          aestheticSyncScore: Math.max(80, 92 - idx * 3),
          vectorSimilarityDistance: Number((0.112 + idx * 0.02).toFixed(3)),
          highlightedKeywords: movie.keywords.slice(0, 3),
          languageMatchNote: movie.originalLanguage !== 'en' ? `Acclaimed ${movie.originalLanguage.toUpperCase()} film selection` : undefined,
        },
        scoreBreakdown: {
          moodMatch: Math.max(75, 98 - idx * 4),
          semanticSimilarity: 0.91,
          contentGenreScore: 88,
          userRatingScore: Math.round(movie.rating * 10),
          popularityWeight: Math.round(movie.popularityScore * 10),
        },
      }));
      setRecommendations(fallbackRecs);
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleWatchlist = (movie: Movie) => {
    setWatchlist((prev) => {
      const exists = prev.some((m) => m.id === movie.id);
      if (exists) {
        return prev.filter((m) => m.id !== movie.id);
      } else {
        return [...prev, movie];
      }
    });
  };

  const isMovieInWatchlist = (movie: Movie) => {
    return watchlist.some((m) => m.id === movie.id);
  };

  const featuredRecommendation = recommendations[0];

  return (
    <div className="w-full min-h-screen bg-[#050505] text-white font-sans flex flex-col antialiased selection:bg-red-600 selection:text-white">
      {/* Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        watchlistCount={watchlist.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 p-6 md:p-10 max-w-7xl w-full mx-auto flex flex-col gap-8">
        {activeTab === 'discover' && (
          <>
            {/* Mood Input Section */}
            <MoodInputSection
              currentPrompt={currentPrompt}
              onRecalibrate={(prompt) => fetchRecommendations(prompt, selectedLanguageFilter)}
              isLoading={isLoading}
            />

            {/* Language Filter Chips */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
              <span className="text-[10px] font-mono uppercase font-bold text-gray-400 flex items-center gap-1.5 shrink-0 mr-1">
                <Globe className="w-3.5 h-3.5 text-red-500" />
                Language Filter:
              </span>
              {LANGUAGE_CHIPS.map((chip) => {
                const isActive = selectedLanguageFilter === chip.code;
                return (
                  <button
                    key={chip.code}
                    onClick={() => setSelectedLanguageFilter(chip.code)}
                    className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer shrink-0 border ${
                      isActive
                        ? 'bg-red-600 border-red-600 text-white shadow-lg shadow-red-600/30'
                        : 'bg-[#111]/80 border-white/10 text-gray-400 hover:text-white hover:border-white/20'
                    }`}
                  >
                    {chip.label}
                  </button>
                );
              })}
            </div>

            {/* Featured Recommendation */}
            {isLoading ? (
              <div className="h-[460px] bg-[#111]/80 backdrop-blur-2xl border border-white/10 rounded-2xl flex flex-col items-center justify-center p-8 text-center animate-pulse">
                <div className="w-12 h-12 rounded-full border-2 border-red-600 border-t-transparent animate-spin mb-4"></div>
                <h3 className="text-sm font-bold uppercase tracking-widest text-red-500 mb-1">
                  Evaluating All-Language Embeddings & Plot Metadata...
                </h3>
                <p className="text-xs text-gray-500 max-w-md">
                  SentenceTransformers 384-D vector search & Gemini 2.5 Flash natural language reasoning in progress...
                </p>
              </div>
            ) : featuredRecommendation ? (
              <FeaturedRecommendation
                recommendation={featuredRecommendation}
                onSelectMovie={setSelectedMovie}
                isInWatchlist={isMovieInWatchlist(featuredRecommendation.movie)}
                onToggleWatchlist={handleToggleWatchlist}
              />
            ) : null}

            {/* Quick Picks Row */}
            {!isLoading && recommendations.length > 1 && (
              <QuickPicksRow
                recommendations={recommendations}
                onSelectMovie={setSelectedMovie}
                onViewPipeline={() => setActiveTab('pipeline')}
              />
            )}
          </>
        )}

        {activeTab === 'pipeline' && <AIPipelineVisualizer />}

        {activeTab === 'admin' && <AdminDashboard />}

        {activeTab === 'watchlist' && (
          <WatchlistAndHistory
            mode="watchlist"
            watchlist={watchlist}
            onRemoveFromWatchlist={handleToggleWatchlist}
            onSelectMovie={setSelectedMovie}
            history={[]}
            onClearHistory={() => {}}
          />
        )}

        {activeTab === 'history' && (
          <WatchlistAndHistory
            mode="history"
            watchlist={[]}
            onRemoveFromWatchlist={() => {}}
            onSelectMovie={setSelectedMovie}
            history={history}
            onClearHistory={() => setHistory([])}
          />
        )}
      </main>

      {/* Footer removed */}

      {/* Movie Detail Modal */}
      {selectedMovie && (
        <MovieDetailModal
          movie={selectedMovie}
          recommendation={recommendations.find((r) => r.movie.id === selectedMovie.id)}
          onClose={() => setSelectedMovie(null)}
          isInWatchlist={isMovieInWatchlist(selectedMovie)}
          onToggleWatchlist={handleToggleWatchlist}
        />
      )}

      {/* Auth Modal */}
      <AuthModal />

      {/* Multi-step Onboarding Modal */}
      <OnboardingModal />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainAppContent />
    </AuthProvider>
  );
}
