import React, { useState } from 'react';
import { Movie, Recommendation } from '../types';
import { X, Play, Bookmark, Check, Star, Brain, Volume2, VolumeX, Database, Hash, DollarSign, Clock, Globe, TrendingUp, Languages } from 'lucide-react';

interface MovieDetailModalProps {
  movie: Movie;
  recommendation?: Recommendation;
  onClose: () => void;
  isInWatchlist: boolean;
  onToggleWatchlist: (movie: Movie) => void;
}

export const MovieDetailModal: React.FC<MovieDetailModalProps> = ({
  movie,
  recommendation,
  onClose,
  isInWatchlist,
  onToggleWatchlist,
}) => {
  const [isPlayingTrailer, setIsPlayingTrailer] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  const languageCode = (movie.originalLanguage || (movie as any).original_language || 'en').toLowerCase();
  const isForeignLanguage = languageCode !== 'en';

  const languageNames: Record<string, string> = {
    ja: 'Japanese',
    ko: 'Korean',
    hi: 'Hindi',
    fr: 'French',
    es: 'Spanish',
    pt: 'Portuguese',
    de: 'German',
    it: 'Italian',
    zh: 'Chinese',
  };
  const languageLabel = languageNames[languageCode] || languageCode.toUpperCase();

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-2xl flex items-center justify-center p-4 md:p-8 overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-[#111]/90 border border-white/10 rounded-2xl overflow-hidden shadow-2xl my-auto border-t-white/20">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-30 p-2.5 rounded-full bg-black/60 hover:bg-black text-white border border-white/10 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Backdrop Image or Simulated Trailer Player */}
        <div className="relative h-72 md:h-96 w-full bg-neutral-900 overflow-hidden">
          {isPlayingTrailer ? (
            <div className="w-full h-full bg-black flex flex-col items-center justify-center text-center p-6 relative">
              <div className="w-16 h-16 rounded-full bg-red-600/20 border border-red-600 flex items-center justify-center text-red-500 mb-4 animate-pulse">
                <Play className="w-8 h-8 fill-red-500" />
              </div>
              <p className="text-sm font-bold text-white uppercase tracking-wider mb-1">
                Simulating HD Trailer Playback: {movie.title}
              </p>
              <p className="text-xs text-gray-400 max-w-md">
                Stream audio-visual ambiance aligned with {movie.aestheticAttributes.music}.
              </p>

              <button
                onClick={() => setIsMuted(!isMuted)}
                className="absolute bottom-4 right-4 p-2 bg-white/10 rounded-lg text-white text-xs flex items-center gap-1.5 cursor-pointer"
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                {isMuted ? 'Muted' : 'Sound Active'}
              </button>
            </div>
          ) : (
            <>
              <img
                src={movie.backdropUrl || movie.posterUrl}
                alt={movie.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#111] via-[#111]/40 to-transparent"></div>

              <button
                onClick={() => setIsPlayingTrailer(true)}
                className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-red-600 hover:bg-red-700 text-white flex items-center justify-center shadow-xl shadow-red-600/40 hover:scale-110 transition-all cursor-pointer z-20"
              >
                <Play className="w-7 h-7 fill-white ml-1" />
              </button>
            </>
          )}

          {/* Title & Metadata Overlay */}
          <div className="absolute bottom-6 left-6 right-6 z-10">
            <div className="flex flex-wrap items-center gap-2 mb-2">
              {recommendation && (
                <span className="px-2.5 py-1 bg-red-600 text-[10px] font-black uppercase rounded text-white tracking-wider">
                  {recommendation.matchPercentage}% Mood Match
                </span>
              )}
              {isForeignLanguage && (
                <span className="px-2.5 py-1 bg-indigo-600/30 border border-indigo-500/50 text-indigo-300 text-[10px] font-bold font-mono uppercase rounded tracking-wider flex items-center gap-1.5 shadow-lg backdrop-blur-md">
                  <Globe className="w-3.5 h-3.5 text-indigo-400" />
                  Foreign Language Film ({languageLabel})
                </span>
              )}
              <span className="px-2 py-0.5 bg-white/10 text-[10px] font-mono text-gray-300 rounded border border-white/10">
                TMDB #{movie.tmdbId}
              </span>
              {movie.movieLensId && (
                <span className="px-2 py-0.5 bg-white/10 text-[10px] font-mono text-gray-300 rounded border border-white/10">
                  MovieLens #{movie.movieLensId}
                </span>
              )}
              {movie.descriptionStatus && (
                <span className={`px-2 py-0.5 text-[10px] font-mono rounded border uppercase font-bold ${
                  movie.descriptionStatus === 'incomplete'
                    ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                    : movie.descriptionStatus === 'fallback_english'
                    ? 'bg-blue-500/20 text-blue-400 border-blue-500/40'
                    : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                }`}>
                  Status: {movie.descriptionStatus.replace('_', ' ')}
                </span>
              )}
            </div>

            <h2 className="text-3xl md:text-5xl font-light italic tracking-tight text-white">
              {movie.title}
            </h2>
            <div className="flex flex-wrap items-center gap-3 text-xs text-gray-300 font-medium mt-2">
              <span>{movie.year}</span>
              <span>•</span>
              <span>{movie.genres.join(' / ')}</span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-gray-400" />
                {movie.runtime || 'N/A'}
              </span>
              <span>•</span>
              <span className="text-amber-400 font-bold flex items-center gap-1">
                <Star className="w-3.5 h-3.5 fill-amber-400" />
                {movie.rating} / 10 ({movie.voteCount?.toLocaleString() || '4,200'} votes)
              </span>
            </div>
          </div>
        </div>

        {/* Modal Scrollable Details */}
        <div className="p-6 md:p-8 space-y-6 max-h-[50vh] overflow-y-auto">
          {/* Foreign Language Transparency Banner */}
          {isForeignLanguage && (
            <div className="p-3.5 rounded-xl bg-indigo-950/40 border border-indigo-500/30 flex items-center justify-between text-xs text-indigo-200">
              <span className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-indigo-400 shrink-0" />
                <span>
                  <strong className="text-white font-semibold">Global Catalog Selection ({languageLabel}):</strong> This movie was selected from MoodFlix's multi-language vector database to best match your emotional prompt.
                </span>
              </span>
              <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 text-[10px] font-mono font-bold uppercase shrink-0 border border-indigo-500/30">
                {languageCode.toUpperCase()}
              </span>
            </div>
          )}

          {/* Overview Plot */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">
              Synopsis & Plot Narrative
            </h3>
            <p className="text-sm md:text-base text-gray-200 leading-relaxed font-light">
              {movie.overview && movie.overview.trim().length > 0 ? movie.overview : 'No synopsis overview available for this title.'}
            </p>
          </div>

          {/* Explainable AI Callout */}
          {recommendation && (
            <div className="p-5 rounded-xl bg-black/60 border border-white/10 space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-red-500">
                <Brain className="w-4 h-4" />
                Explainable Neural Inference Rationale
              </div>
              <p className="text-xs md:text-sm text-gray-300 italic leading-relaxed">
                "{recommendation.reasoning.whyThisMovie}"
              </p>
            </div>
          )}

          {/* Cast, Crew, Budget & Financials */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            <div className="p-3.5 bg-black/40 rounded-xl border border-white/5">
              <span className="text-[10px] uppercase text-gray-500 font-bold block mb-1">Director / Crew</span>
              <span className="text-white font-medium">{movie.director}</span>
            </div>

            <div className="p-3.5 bg-black/40 rounded-xl border border-white/5">
              <span className="text-[10px] uppercase text-gray-500 font-bold block mb-1">Top Cast</span>
              <span className="text-white font-medium">{movie.cast.join(', ')}</span>
            </div>

            <div className="p-3.5 bg-black/40 rounded-xl border border-white/5">
              <span className="text-[10px] uppercase text-gray-500 font-bold block mb-1">Runtime & Language</span>
              <div className="text-white font-medium space-y-1">
                <div className="flex items-center gap-1.5 text-gray-200">
                  <Clock className="w-3.5 h-3.5 text-red-400 shrink-0" />
                  Runtime: <span className="font-mono">{movie.runtime || 'N/A'}</span>
                </div>
                <div className="flex items-center gap-1.5 text-indigo-300 font-mono text-[11px]">
                  <Languages className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  Language: {languageLabel} {isForeignLanguage ? '(Global)' : '(Original)'}
                </div>
              </div>
            </div>

            <div className="p-3.5 bg-black/40 rounded-xl border border-white/5">
              <span className="text-[10px] uppercase text-gray-500 font-bold block mb-1">Financial Metrics</span>
              <div className="text-white font-medium space-y-1 font-mono text-[11px]">
                <div className="flex items-center gap-1 text-emerald-400">
                  <DollarSign className="w-3.5 h-3.5 shrink-0" />
                  Budget: {movie.budget && movie.budget > 0 ? `$${(movie.budget / 1000000).toFixed(1)}M` : 'N/A'}
                </div>
                <div className="flex items-center gap-1 text-blue-400">
                  <TrendingUp className="w-3.5 h-3.5 shrink-0" />
                  Revenue: {movie.revenue && movie.revenue > 0 ? `$${(movie.revenue / 1000000).toFixed(1)}M` : 'N/A'}
                </div>
              </div>
            </div>
          </div>

          {/* Content Hash & Vector Identity */}
          {movie.contentHash && (
            <div className="p-3.5 bg-black/40 rounded-xl border border-white/5 flex items-center justify-between text-[10px] font-mono text-gray-400">
              <span className="flex items-center gap-1.5">
                <Hash className="w-3.5 h-3.5 text-red-500" />
                Incremental Vector Hash: <span className="text-white">{movie.contentHash}</span>
              </span>
              <span className="text-emerald-400">FAISS Index Synced</span>
            </div>
          )}

          {/* Aesthetic Attributes Grid */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-3">
              Aesthetic & Cinematic Profiling
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3.5 bg-black/40 rounded-xl border border-white/5">
                <span className="text-[10px] uppercase text-gray-500 font-bold block mb-1">Cinematography Style</span>
                <span className="text-white font-medium">{movie.aestheticAttributes.cinematography}</span>
              </div>
              <div className="p-3.5 bg-black/40 rounded-xl border border-white/5">
                <span className="text-[10px] uppercase text-gray-500 font-bold block mb-1">Rhythmic Pace</span>
                <span className="text-white font-medium">{movie.aestheticAttributes.pace}</span>
              </div>
              <div className="p-3.5 bg-black/40 rounded-xl border border-white/5">
                <span className="text-[10px] uppercase text-gray-500 font-bold block mb-1">Atmospheric Tone</span>
                <span className="text-white font-medium">{movie.aestheticAttributes.tone}</span>
              </div>
              <div className="p-3.5 bg-black/40 rounded-xl border border-white/5">
                <span className="text-[10px] uppercase text-gray-500 font-bold block mb-1">Musical Score Palette</span>
                <span className="text-white font-medium">{movie.aestheticAttributes.music}</span>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="pt-4 border-t border-white/10 flex gap-4">
            <button
              onClick={() => onToggleWatchlist(movie)}
              className={`flex-1 py-3.5 font-bold uppercase tracking-widest rounded-xl transition-all text-xs flex items-center justify-center gap-2 cursor-pointer border ${
                isInWatchlist
                  ? 'bg-red-600/20 border-red-600 text-red-400'
                  : 'bg-white/10 hover:bg-white/20 border-white/10 text-white'
              }`}
            >
              {isInWatchlist ? (
                <>
                  <Check className="w-4 h-4" />
                  In Watchlist
                </>
              ) : (
                <>
                  <Bookmark className="w-4 h-4" />
                  Add to Watchlist
                </>
              )}
            </button>

            <button
              onClick={onClose}
              className="px-6 py-3.5 bg-transparent border border-white/20 text-gray-300 hover:text-white hover:bg-white/5 font-bold uppercase tracking-widest rounded-xl transition-colors text-xs cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

