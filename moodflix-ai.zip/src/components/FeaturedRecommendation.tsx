import React from 'react';
import { Movie, Recommendation } from '../types';
import { Play, Bookmark, Check, Star, Brain, Sparkles, Film, ArrowRight } from 'lucide-react';

interface FeaturedRecommendationProps {
  recommendation: Recommendation;
  onSelectMovie: (movie: Movie) => void;
  isInWatchlist: boolean;
  onToggleWatchlist: (movie: Movie) => void;
}

export const FeaturedRecommendation: React.FC<FeaturedRecommendationProps> = ({
  recommendation,
  onSelectMovie,
  isInWatchlist,
  onToggleWatchlist,
}) => {
  const { movie, matchPercentage, confidenceScore, reasoning, scoreBreakdown } = recommendation;

  return (
    <section className="bg-[#111]/80 backdrop-blur-2xl border border-white/10 hover:border-white/20 rounded-2xl overflow-hidden shadow-2xl transition-all relative group">
      <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[460px]">
        
        {/* Left Side: Visual Backdrop Media */}
        <div className="lg:col-span-7 relative overflow-hidden min-h-[280px] lg:min-h-full cursor-pointer" onClick={() => onSelectMovie(movie)}>
          <img
            src={movie.backdropUrl || movie.posterUrl}
            alt={movie.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#111] via-[#111]/30 to-transparent lg:bg-gradient-to-r lg:from-transparent lg:via-[#111]/40 lg:to-[#111]"></div>
          
          {/* Match Pill Overlay */}
          <div className="absolute top-6 left-6 z-10 flex flex-wrap items-center gap-2">
            <span className="px-3 py-1.5 bg-red-600 text-white font-black uppercase text-xs rounded-lg tracking-wider shadow-xl shadow-red-600/40 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              {matchPercentage}% Mood Match
            </span>
            <span className="px-2.5 py-1 bg-black/60 backdrop-blur-md border border-white/20 text-gray-300 font-mono text-[11px] rounded-lg">
              Similarity Dist: {reasoning.vectorSimilarityDistance}
            </span>
            {movie.descriptionStatus && movie.descriptionStatus !== 'complete' && (
              <span className={`px-2.5 py-1 font-mono text-[10px] uppercase font-bold rounded-lg border backdrop-blur-md ${
                movie.descriptionStatus === 'incomplete'
                  ? 'bg-amber-500/30 text-amber-300 border-amber-500/50'
                  : 'bg-blue-500/30 text-blue-300 border-blue-500/50'
              }`}>
                {movie.descriptionStatus.replace('_', ' ')}
              </span>
            )}
          </div>

          {/* Quick Play Trigger */}
          <button
            onClick={() => onSelectMovie(movie)}
            className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-red-600/90 hover:bg-red-600 text-white flex items-center justify-center shadow-2xl shadow-red-600/50 hover:scale-110 transition-all cursor-pointer opacity-90 group-hover:opacity-100"
          >
            <Play className="w-7 h-7 fill-white ml-1" />
          </button>
        </div>

        {/* Right Side: Details & Explainable AI Box */}
        <div className="lg:col-span-5 p-6 md:p-8 flex flex-col justify-between space-y-6 bg-black/40 backdrop-blur-md">
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-[10px] font-mono text-red-500 font-bold uppercase tracking-widest">
              <Brain className="w-3.5 h-3.5" />
              Primary Neural Inference Match
            </div>

            <div>
              <h1 className="text-3xl md:text-4xl font-light italic text-white tracking-tight leading-tight group-hover:text-red-400 transition-colors">
                {movie.title}
              </h1>
              <div className="flex flex-wrap items-center gap-2 text-xs text-gray-300 font-medium mt-1">
                <span>{movie.year}</span>
                <span>•</span>
                <span>{movie.runtime}</span>
                <span>•</span>
                <span>{movie.genres.join(' / ')}</span>
                <span>•</span>
                <span className="text-amber-400 font-bold flex items-center gap-1">
                  <Star className="w-3 h-3 fill-amber-400" />
                  {movie.rating}
                </span>
              </div>
            </div>

            {/* AI Explanation Callout */}
            <div className="p-4 rounded-xl bg-black/60 border border-white/10 space-y-2">
              <span className="text-[10px] uppercase font-bold text-red-400 tracking-wider flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                Why This Recommendation?
              </span>
              <p className="text-xs md:text-sm text-gray-200 italic font-light leading-relaxed">
                "{reasoning.whyThisMovie}"
              </p>
              {reasoning.languageMatchNote && (
                <div className="pt-2 border-t border-white/10 text-[10px] font-mono text-amber-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                  <Film className="w-3 h-3" />
                  {reasoning.languageMatchNote}
                </div>
              )}
            </div>

            {/* Keyword Tags */}
            <div className="flex flex-wrap gap-1.5">
              {movie.keywords.map((kw, i) => (
                <span
                  key={i}
                  className="px-2.5 py-1 bg-white/5 border border-white/10 rounded-md text-[10px] font-mono text-gray-300 uppercase"
                >
                  #{kw}
                </span>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-4 border-t border-white/10 flex items-center gap-3">
            <button
              onClick={() => onSelectMovie(movie)}
              className="flex-1 py-3 bg-white hover:bg-gray-200 text-black font-bold uppercase text-xs tracking-widest rounded-xl transition-all shadow-xl flex items-center justify-center gap-2 cursor-pointer"
            >
              <Play className="w-4 h-4 fill-black" />
              Watch Details
            </button>

            <button
              onClick={() => onToggleWatchlist(movie)}
              className={`p-3 rounded-xl border transition-all cursor-pointer ${
                isInWatchlist
                  ? 'bg-red-600/20 border-red-600 text-red-400'
                  : 'bg-white/10 hover:bg-white/20 border-white/10 text-white'
              }`}
              title={isInWatchlist ? 'Remove from Watchlist' : 'Add to Watchlist'}
            >
              {isInWatchlist ? <Check className="w-5 h-5 text-red-400" /> : <Bookmark className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
