import React, { useState } from 'react';
import { Sparkles, Film, Bookmark, Clock, Cpu, LogOut, ChevronDown, LogIn, ShieldCheck, Sliders, LayoutDashboard } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

interface HeaderProps {
  activeTab: 'discover' | 'history' | 'watchlist' | 'pipeline' | 'admin';
  setActiveTab: (tab: 'discover' | 'history' | 'watchlist' | 'pipeline' | 'admin') => void;
  watchlistCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  watchlistCount,
}) => {
  const { user, isAuthenticated, logout, openAuthModal, openOnboardingModal } = useAuth();
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full bg-black/60 backdrop-blur-xl border-b border-white/10 px-6 md:px-10 py-4 flex items-center justify-between transition-all">
      {/* Brand Logo & Tagline */}
      <div
        className="flex items-center gap-3 cursor-pointer group"
        onClick={() => setActiveTab('discover')}
      >
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-600 via-red-700 to-black border border-red-500/30 flex items-center justify-center shadow-lg shadow-red-600/20 group-hover:scale-105 transition-transform">
          <Film className="w-5 h-5 text-white" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xl font-black uppercase tracking-tighter text-white">
              MoodFlix<span className="text-red-500">.AI</span>
            </span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs (SRS Spec removed from live navigation) */}
      <nav className="hidden lg:flex items-center bg-[#111]/80 backdrop-blur-md border border-white/10 p-1.5 rounded-2xl shadow-inner">
        <button
          onClick={() => setActiveTab('discover')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
            activeTab === 'discover'
              ? 'bg-red-600 text-white shadow-lg shadow-red-600/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          Discover
        </button>

        <button
          onClick={() => setActiveTab('history')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
            activeTab === 'history'
              ? 'bg-red-600 text-white shadow-lg shadow-red-600/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          My History
        </button>

        <button
          onClick={() => setActiveTab('watchlist')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer relative ${
            activeTab === 'watchlist'
              ? 'bg-red-600 text-white shadow-lg shadow-red-600/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Bookmark className="w-3.5 h-3.5" />
          Watchlist
          {watchlistCount > 0 && (
            <span className="ml-1 px-1.5 py-0.2 bg-white text-black font-black text-[9px] rounded-full">
              {watchlistCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('pipeline')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
            activeTab === 'pipeline'
              ? 'bg-red-600 text-white shadow-lg shadow-red-600/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Cpu className="w-3.5 h-3.5" />
          AI Pipeline
        </button>

        {user?.role === 'admin' && (
          <button
            onClick={() => setActiveTab('admin')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              activeTab === 'admin'
                ? 'bg-red-600 text-white shadow-lg shadow-red-600/30'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <LayoutDashboard className="w-3.5 h-3.5" />
            Admin
          </button>
        )}
      </nav>

      {/* Auth & User Menu Area */}
      <div className="flex items-center gap-3">
        {isAuthenticated && user ? (
          <div className="relative">
            <button
              onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
              className="flex items-center gap-3 bg-[#111]/90 hover:bg-[#1a1a1a] border border-white/10 hover:border-white/20 p-1.5 pr-3 rounded-2xl transition-all cursor-pointer"
            >
              <img
                src={user.avatarUrl}
                alt={user.displayName}
                className="w-8 h-8 rounded-xl object-cover border border-white/20"
              />
              <div className="text-left hidden sm:block">
                <div className="text-xs font-bold text-white flex items-center gap-1.5">
                  {user.displayName}
                  {user.role === 'admin' && <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />}
                </div>
                <div className="text-[9px] font-mono uppercase text-gray-400">
                  {user.role === 'admin' ? 'Admin Tier' : `${user.subscriptionTier} Tier`}
                </div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
            </button>

            {/* Profile Dropdown Menu */}
            {isUserMenuOpen && (
              <div className="absolute right-0 mt-2 w-60 bg-[#111]/95 border border-white/10 rounded-2xl shadow-2xl p-2 z-50 backdrop-blur-2xl animate-in fade-in duration-150">
                <div className="p-3 border-b border-white/10 mb-1">
                  <p className="text-xs font-bold text-white flex items-center gap-1.5">
                    {user.displayName}
                    {user.role === 'admin' && (
                      <span className="px-1.5 py-0.2 bg-red-600/30 text-red-400 text-[8px] font-mono uppercase font-bold rounded">
                        Admin
                      </span>
                    )}
                  </p>
                  <p className="text-[10px] text-gray-400 truncate">{user.email}</p>
                </div>

                <button
                  onClick={() => {
                    openOnboardingModal();
                    setIsUserMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-xs text-gray-300 hover:text-white hover:bg-white/5 rounded-xl transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <Sliders className="w-3.5 h-3.5 text-red-400" />
                  Edit Preferences
                </button>

                <button
                  onClick={() => {
                    setActiveTab('watchlist');
                    setIsUserMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-xs text-gray-300 hover:text-white hover:bg-white/5 rounded-xl transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <Bookmark className="w-3.5 h-3.5" />
                  My Saved Watchlist ({watchlistCount})
                </button>

                <button
                  onClick={() => {
                    setActiveTab('history');
                    setIsUserMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-xs text-gray-300 hover:text-white hover:bg-white/5 rounded-xl transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <Clock className="w-3.5 h-3.5" />
                  Recalibration History
                </button>

                {user.role === 'admin' && (
                  <button
                    onClick={() => {
                      setActiveTab('admin');
                      setIsUserMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 text-xs text-red-400 hover:text-white hover:bg-red-600/20 rounded-xl transition-colors flex items-center gap-2 cursor-pointer font-bold"
                  >
                    <LayoutDashboard className="w-3.5 h-3.5" />
                    Admin Dashboard
                  </button>
                )}

                <div className="border-t border-white/10 my-1"></div>

                <button
                  onClick={() => {
                    logout();
                    setIsUserMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-xs text-gray-400 hover:text-red-400 hover:bg-red-600/10 rounded-xl transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  Sign Out
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <button
              onClick={() => openAuthModal('login')}
              className="px-4 py-2 bg-white/10 hover:bg-white/20 border border-white/10 text-white font-bold uppercase text-xs tracking-wider rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <LogIn className="w-3.5 h-3.5" />
              Sign In
            </button>

            <button
              onClick={() => openAuthModal('register')}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold uppercase text-xs tracking-wider rounded-xl transition-colors shadow-lg shadow-red-600/30 cursor-pointer hidden sm:block"
            >
              Register
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
