import React, { useState } from 'react';
import { SRS_DOCUMENT } from '../data/srsDocument';
import { BookOpen, Search, Code, Database, CheckCircle2, FileText, ChevronRight } from 'lucide-react';

export const SRSDocumentViewer: React.FC = () => {
  const [activeSectionId, setActiveSectionId] = useState('sec-1');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredSections = SRS_DOCUMENT.filter(
    (sec) =>
      sec.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sec.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const activeSection = SRS_DOCUMENT.find((sec) => sec.id === activeSectionId) || SRS_DOCUMENT[0];

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="bg-[#111] border border-white/10 p-6 md:p-8 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-red-500 font-bold text-xs uppercase tracking-widest mb-1">
            <BookOpen className="w-4 h-4" />
            Milestone 1 — Technical Deliverable
          </div>
          <h1 className="text-2xl md:text-3xl font-black tracking-tight text-white uppercase">
            Software Requirements Specification (SRS)
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            System Architecture, Data Contracts, AI Pipeline Mechanics, & Relational ER Specifications
          </p>
        </div>

        <div className="relative w-full md:w-64">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search SRS specifications..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-black/50 border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder:text-gray-500 focus:outline-none focus:border-red-500"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        {/* Table of Contents Sidebar */}
        <div className="md:col-span-4 bg-[#111] border border-white/10 p-4 rounded-2xl h-fit space-y-2">
          <div className="text-[10px] uppercase tracking-widest text-gray-500 font-bold px-3 py-2 border-b border-white/10">
            SRS Document Outline
          </div>

          {filteredSections.map((sec) => (
            <button
              key={sec.id}
              onClick={() => setActiveSectionId(sec.id)}
              className={`w-full text-left p-3 rounded-xl transition-all flex items-center justify-between group ${
                activeSectionId === sec.id
                  ? 'bg-red-600 text-white shadow-lg shadow-red-600/30 font-bold'
                  : 'bg-white/5 hover:bg-white/10 text-gray-300'
              }`}
            >
              <div className="min-w-0 flex-1 pr-2">
                <div className="text-xs truncate">{sec.title}</div>
                <div className={`text-[10px] truncate ${activeSectionId === sec.id ? 'text-white/80' : 'text-gray-500'}`}>
                  {sec.subtitle}
                </div>
              </div>
              <ChevronRight className={`w-4 h-4 shrink-0 transition-transform ${activeSectionId === sec.id ? 'translate-x-1' : 'opacity-0 group-hover:opacity-100'}`} />
            </button>
          ))}
        </div>

        {/* Section Content Display */}
        <div className="md:col-span-8 bg-[#111] border border-white/10 p-6 md:p-8 rounded-2xl space-y-6">
          <div className="border-b border-white/10 pb-4">
            <h2 className="text-xl font-bold text-white mb-1">{activeSection.title}</h2>
            <div className="text-xs text-red-400 font-semibold uppercase tracking-wider">
              {activeSection.subtitle}
            </div>
          </div>

          <div className="text-sm text-gray-300 leading-relaxed space-y-4 whitespace-pre-line font-light">
            {activeSection.content}
          </div>

          {/* Subsections if available */}
          {activeSection.subsections?.map((sub, idx) => (
            <div key={idx} className="mt-6 p-5 rounded-xl bg-black/50 border border-white/10 space-y-3">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-red-500" />
                {sub.title}
              </h3>
              <p className="text-xs text-gray-300 leading-relaxed whitespace-pre-line">
                {sub.content}
              </p>

              {sub.codeSnippet && (
                <div className="mt-3">
                  <div className="flex items-center gap-2 text-[10px] text-gray-400 font-mono mb-1">
                    <Code className="w-3.5 h-3.5 text-red-400" />
                    Reference Code Snippet
                  </div>
                  <pre className="bg-black/80 border border-white/10 p-4 rounded-lg font-mono text-xs text-green-400 overflow-x-auto">
                    <code>{sub.codeSnippet}</code>
                  </pre>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
