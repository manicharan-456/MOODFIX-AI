import React, { useState } from 'react';
import { Cpu, Database, Brain, Sparkles, Server, CheckCircle, RefreshCw, Activity, Zap } from 'lucide-react';
import { IngestionJobStats } from '../types';

export const AIPipelineVisualizer: React.FC = () => {
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStats, setSyncStats] = useState<IngestionJobStats | null>({
    totalProcessed: 8,
    embeddingsGenerated: 2,
    cachedEmbeddingsReused: 6,
    rateLimitBackoffsTriggered: 1,
    lastSyncTimestamp: new Date().toISOString(),
  });

  const handleTriggerSync = async () => {
    setIsSyncing(true);
    try {
      const res = await fetch('/api/admin/ingestion-sync', { method: 'POST' });
      const data = await res.json();
      if (data.stats) {
        setSyncStats(data.stats);
      }
    } catch (err) {
      console.error('Ingestion sync failed:', err);
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="bg-[#111]/80 backdrop-blur-2xl border border-white/10 p-6 md:p-8 rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600/20 text-red-400 border border-red-600/30 text-[10px] uppercase font-bold tracking-widest mb-2">
            <Cpu className="w-3.5 h-3.5" />
            Neural Architecture Dashboard
          </div>
          <h1 className="text-2xl md:text-3xl font-light italic text-white tracking-tight">
            Hybrid Vector Ranking & Ingestion Pipeline
          </h1>
          <p className="text-xs text-gray-400 mt-1 max-w-xl">
            SentenceTransformers 384-dimensional dense semantic embedding index combined with Gemini 2.5 Flash natural language explainability reasoning.
          </p>
        </div>

        <button
          onClick={handleTriggerSync}
          disabled={isSyncing}
          className="px-5 py-3 bg-red-600 hover:bg-red-700 text-white font-bold uppercase text-xs tracking-widest rounded-xl transition-all shadow-lg shadow-red-600/30 flex items-center gap-2 cursor-pointer disabled:opacity-50 shrink-0"
        >
          {isSyncing ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              Syncing MovieLens + TMDB...
            </>
          ) : (
            <>
              <Zap className="w-4 h-4" />
              Trigger Offline Ingestion Sync
            </>
          )}
        </button>
      </div>

      {/* Ingestion Batch Sync Metrics */}
      {syncStats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-[#111]/80 backdrop-blur-xl border border-white/10 p-4 rounded-xl text-center">
            <span className="text-[10px] uppercase text-gray-400 font-bold block mb-1">Total Movies Processed</span>
            <span className="text-2xl font-black text-white">{syncStats.totalProcessed}</span>
          </div>

          <div className="bg-[#111]/80 backdrop-blur-xl border border-white/10 p-4 rounded-xl text-center">
            <span className="text-[10px] uppercase text-gray-400 font-bold block mb-1">New Embeddings Generated</span>
            <span className="text-2xl font-black text-red-500">{syncStats.embeddingsGenerated}</span>
          </div>

          <div className="bg-[#111]/80 backdrop-blur-xl border border-white/10 p-4 rounded-xl text-center">
            <span className="text-[10px] uppercase text-gray-400 font-bold block mb-1">Cached FAISS Vectors Reused</span>
            <span className="text-2xl font-black text-emerald-400">{syncStats.cachedEmbeddingsReused}</span>
          </div>

          <div className="bg-[#111]/80 backdrop-blur-xl border border-white/10 p-4 rounded-xl text-center">
            <span className="text-[10px] uppercase text-gray-400 font-bold block mb-1">TMDB Rate Limit Backoffs</span>
            <span className="text-2xl font-black text-amber-400">{syncStats.rateLimitBackoffsTriggered}</span>
          </div>
        </div>
      )}

      {/* Pipeline Diagram */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#111]/80 backdrop-blur-xl border border-white/10 p-6 rounded-2xl space-y-4">
          <div className="w-10 h-10 rounded-xl bg-red-600/20 border border-red-600/30 flex items-center justify-center text-red-400 font-bold">
            01
          </div>
          <h3 className="text-base font-bold text-white uppercase tracking-wide">
            1. Data Ingestion & Content Hash
          </h3>
          <p className="text-xs text-gray-400 leading-relaxed">
            MovieLens ratings + TMDB metadata (plot, runtime, cast, director, keywords). Generates MD5 content hash per movie. Unchanged hashes reuse existing vectors.
          </p>
          <div className="pt-3 border-t border-white/10 text-[10px] font-mono text-emerald-400 flex items-center gap-1">
            <CheckCircle className="w-3.5 h-3.5" />
            Incremental Embedding Active
          </div>
        </div>

        <div className="bg-[#111]/80 backdrop-blur-xl border border-white/10 p-6 rounded-2xl space-y-4">
          <div className="w-10 h-10 rounded-xl bg-red-600/20 border border-red-600/30 flex items-center justify-center text-red-400 font-bold">
            02
          </div>
          <h3 className="text-base font-bold text-white uppercase tracking-wide">
            2. FAISS Vector Cosine Similarity
          </h3>
          <p className="text-xs text-gray-400 leading-relaxed">
            User natural language mood prompt is converted into a 384-dimensional dense vector via SentenceTransformers. Performs inner-product k-NN search across 8.2M embeddings.
          </p>
          <div className="pt-3 border-t border-white/10 text-[10px] font-mono text-emerald-400 flex items-center gap-1">
            <CheckCircle className="w-3.5 h-3.5" />
            Sub-12ms Vector Search
          </div>
        </div>

        <div className="bg-[#111]/80 backdrop-blur-xl border border-white/10 p-6 rounded-2xl space-y-4">
          <div className="w-10 h-10 rounded-xl bg-red-600/20 border border-red-600/30 flex items-center justify-center text-red-400 font-bold">
            03
          </div>
          <h3 className="text-base font-bold text-white uppercase tracking-wide">
            3. Gemini Explainability Engine
          </h3>
          <p className="text-xs text-gray-400 leading-relaxed">
            Top candidates pass to Gemini 2.5 Flash to synthesize plot-driven, keyword-aware natural language explanations detailing why each film satisfies the user's emotional state.
          </p>
          <div className="pt-3 border-t border-white/10 text-[10px] font-mono text-emerald-400 flex items-center gap-1">
            <CheckCircle className="w-3.5 h-3.5" />
            Structured JSON Schema Response
          </div>
        </div>
      </div>
    </div>
  );
};
