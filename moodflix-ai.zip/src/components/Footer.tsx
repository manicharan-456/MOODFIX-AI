import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="px-6 md:px-10 py-4 bg-black/60 border-t border-white/5 flex flex-col sm:flex-row justify-between items-center text-[10px] uppercase tracking-[0.3em] text-gray-500 gap-2 mt-auto">
      <div className="flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
        <span>Engine Status: Operational</span>
      </div>
      <div>Vector Store: 8.2M Embeddings Synced (FAISS)</div>
      <div>© 2026 MoodFlix AI Labs</div>
    </footer>
  );
};
