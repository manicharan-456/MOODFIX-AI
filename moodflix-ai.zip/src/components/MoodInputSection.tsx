import React, { useState } from 'react';
import { Sparkles, Brain, Cpu, Flame, RefreshCw } from 'lucide-react';

interface MoodInputSectionProps {
  currentPrompt: string;
  onRecalibrate: (prompt: string) => void;
  isLoading: boolean;
}

export const MoodInputSection: React.FC<MoodInputSectionProps> = ({
  currentPrompt,
  onRecalibrate,
  isLoading,
}) => {
  const [inputVal, setInputVal] = useState(currentPrompt);

  const presetMoods = [
    "Stress relief & cozy visual escapism after a hard week",
    "Mind-bending sci-fi heist that challenges perception",
    "Witty Paris romance with whimsical accordion music",
    "High-octane adrenaline chase through neon city streets",
    "Cosmic reflection & profound father-daughter story"
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputVal.trim()) {
      onRecalibrate(inputVal);
    }
  };

  return (
    <section className="bg-[#111]/80 backdrop-blur-2xl border border-white/10 hover:border-white/20 rounded-2xl p-6 md:p-8 shadow-2xl relative overflow-hidden transition-all group">
      {/* Background Subtle Gradient Glow */}
      <div className="absolute -top-24 -left-24 w-72 h-72 bg-red-600/10 rounded-full blur-3xl pointer-events-none group-hover:bg-red-600/15 transition-all"></div>
      <div className="absolute -bottom-24 -right-24 w-72 h-72 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="relative z-10 space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-red-500 mb-1">
              <Brain className="w-4 h-4 animate-pulse" />
              Emotional Input Calibration
            </div>
            <h2 className="text-xl md:text-2xl font-light italic text-white tracking-tight">
              Describe Your Current Mood or Desired Cinematic Feeling
            </h2>
          </div>

          <div className="flex items-center gap-2 text-[10px] font-mono text-gray-400 bg-black/60 px-3 py-1.5 rounded-xl border border-white/10">
            <Cpu className="w-3.5 h-3.5 text-emerald-400" />
            Embedding: SentenceTransformers-384D
          </div>
        </div>

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <textarea
              rows={3}
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder="e.g. I need something uplifting with beautiful cinematography to clear my head..."
              className="w-full bg-black/60 backdrop-blur-md border border-white/10 rounded-xl p-4 text-sm md:text-base text-gray-100 placeholder-gray-600 focus:outline-none focus:border-red-500/80 transition-all resize-none font-light leading-relaxed shadow-inner"
            />
            <div className="absolute bottom-3 right-3 text-[10px] text-gray-500 font-mono">
              {inputVal.length} chars
            </div>
          </div>

          {/* Quick Preset Pills */}
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mr-1 flex items-center gap-1">
              <Flame className="w-3 h-3 text-red-500" />
              Presets:
            </span>
            {presetMoods.map((preset, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setInputVal(preset);
                  onRecalibrate(preset);
                }}
                className="px-3 py-1 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-gray-300 hover:text-white text-[11px] font-medium transition-all cursor-pointer truncate max-w-xs"
              >
                {preset}
              </button>
            ))}
          </div>

          {/* Recalibrate Button */}
          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={isLoading}
              className="px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-bold uppercase text-xs tracking-widest rounded-xl transition-all shadow-lg shadow-red-600/30 hover:scale-105 active:scale-95 flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Running Neural Inference...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Recalibrate Mood Recommendations
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </section>
  );
};
