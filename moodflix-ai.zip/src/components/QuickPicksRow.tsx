import React from 'react';
import { Recommendation, Movie } from '../types';
import { Star, Play, Sparkles, ArrowRight } from 'lucide-react';

interface QuickPicksRowProps {
  recommendations: Recommendation[];
  onSelectMovie: (movie: Movie) => void;
  onViewPipeline: () => void;
}

export const QuickPicksRow: React.FC<QuickPicksRowProps> = ({
  recommendations,
  onSelectMovie,
  onViewPipeline,
}) => {
  const alternativePicks = recommendations.slice(1, 4);

  return (
    <section className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-lg md:text-xl font-bold uppercase tracking-tight text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-red-500" />
            Alternative Neural Vector Matches
          </h2>
          <p className="text-xs text-gray-400">
            Top candidates ranked by cosine vector similarity and aesthetic metadata profiling
          </p>
        </div>

        <button
          onClick={onViewPipeline}
          className="text-xs text-red-400 hover:text-red-300 font-bold uppercase tracking-wider flex items-center gap-1 cursor-pointer"
        >
          View FAISS Pipeline
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {alternativePicks.map((rec) => (
          <div
            key={rec.movie.id}
            onClick={() => onSelectMovie(rec.movie)}
            className="bg-[#111]/80 backdrop-blur-xl border border-white/10 hover:border-white/30 rounded-2xl overflow-hidden group transition-all duration-300 cursor-pointer flex flex-col justify-between hover:shadow-xl hover:shadow-red-600/10"
          >
            <div className="relative h-48 overflow-hidden">
              <img
                src={rec.movie.backdropUrl || rec.movie.posterUrl}
                alt={rec.movie.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#111] via-[#111]/40 to-transparent"></div>

              {/* Match Percentage Pill */}
              <div className="absolute top-3 left-3 bg-red-600/90 backdrop-blur-md px-2.5 py-1 rounded-lg text-white font-black text-[10px] uppercase tracking-wider">
                {rec.matchPercentage}% Match
              </div>

              <div className="absolute bottom-3 left-4 right-4 z-10">
                <h3 className="text-lg font-light italic text-white group-hover:text-red-400 transition-colors">
                  {rec.movie.title}
                </h3>
                <div className="flex items-center gap-2 text-xs text-gray-300 mt-0.5">
                  <span>{rec.movie.year}</span>
                  <span>•</span>
                  <span>{rec.movie.runtime}</span>
                  <span>•</span>
                  <span className="text-amber-400 font-bold flex items-center gap-1">
                    <Star className="w-3 h-3 fill-amber-400" />
                    {rec.movie.rating}
                  </span>
                </div>
              </div>
            </div>

            <div className="p-4 bg-black/40 space-y-3 flex-1 flex flex-col justify-between">
              <p className="text-xs text-gray-400 line-clamp-2 italic font-light">
                "{rec.reasoning.whyThisMovie}"
              </p>

              <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[10px] uppercase font-mono text-gray-400">
                <span>Director: {rec.movie.director}</span>
                <span className="text-red-400 font-bold flex items-center gap-1">
                  <Play className="w-3 h-3 fill-red-400" />
                  Inspect
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
