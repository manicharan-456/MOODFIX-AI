import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { Sparkles, Check, ArrowRight, ShieldCheck, Languages, Film, Ban, X, Compass, CheckCircle2 } from 'lucide-react';

const GENRE_OPTIONS = [
  'Adventure', 'Comedy', 'Drama', 'Fantasy', 'Romance',
  'Thriller', 'Animation', 'Crime', 'Sci-Fi', 'Mystery', 'Biography'
];

const LANGUAGE_OPTIONS = [
  { code: 'en', label: 'English' },
  { code: 'ja', label: 'Japanese (日本語)' },
  { code: 'ko', label: 'Korean (한국어)' },
  { code: 'hi', label: 'Hindi (हिंदी)' },
  { code: 'fr', label: 'French (Français)' },
  { code: 'es', label: 'Spanish (Español)' },
  { code: 'pt', label: 'Portuguese (Português)' },
  { code: 'de', label: 'German (Deutsch)' },
  { code: 'it', label: 'Italian (Italiano)' },
];

export const OnboardingModal: React.FC = () => {
  const { user, preferences, isOnboardingOpen, closeOnboardingModal, submitOnboarding } = useAuth();

  const isAdmin = user?.role === 'admin';
  const totalSteps = isAdmin ? 4 : 3;

  const [currentStep, setCurrentStep] = useState<number>(1);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Form State
  const [viewingGoal, setViewingGoal] = useState<string>(preferences?.viewingGoal || 'discover');
  const [favoriteGenres, setFavoriteGenres] = useState<string[]>(preferences?.favoriteGenres || ['Adventure', 'Drama', 'Sci-Fi']);
  const [preferredLanguages, setPreferredLanguages] = useState<string[]>(preferences?.preferredLanguages || ['en', 'ja', 'ko', 'hi', 'fr', 'es']);
  const [dislikedGenres, setDislikedGenres] = useState<string[]>(preferences?.dislikedGenres || ['Horror']);
  const [contentRatingLimit, setContentRatingLimit] = useState<string>(preferences?.contentRatingLimit || 'PG-13');
  const [adminCatalogRegionFocus, setAdminCatalogRegionFocus] = useState<string>(preferences?.adminCatalogRegionFocus || 'global');

  if (!isOnboardingOpen) return null;

  const toggleGenre = (genre: string, setFn: React.Dispatch<React.SetStateAction<string[]>>) => {
    setFn((prev) => (prev.includes(genre) ? prev.filter((g) => g !== genre) : [...prev, genre]));
  };

  const toggleLanguage = (code: string) => {
    setPreferredLanguages((prev) =>
      prev.includes(code) ? (prev.length > 1 ? prev.filter((c) => c !== code) : prev) : [...prev, code]
    );
  };

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep((prev) => prev + 1);
    } else {
      handleSubmit();
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep((prev) => prev - 1);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    await submitOnboarding({
      viewingGoal,
      favoriteGenres,
      preferredLanguages,
      dislikedGenres,
      contentRatingLimit,
      adminCatalogRegionFocus,
      onboardingCompleted: true,
    });
    setIsSubmitting(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-2xl flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-300">
      <div className="relative w-full max-w-2xl bg-[#111]/95 border border-white/10 rounded-2xl overflow-hidden shadow-2xl my-auto border-t-white/20 p-6 md:p-8 space-y-6">
        
        {/* Header & Progress Bar */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-600/20 text-red-400 border border-red-600/30 text-[10px] uppercase font-bold tracking-widest">
              <Sparkles className="w-3.5 h-3.5" />
              MoodFlix Personalization Wizard
            </div>

            <button
              onClick={closeOnboardingModal}
              className="text-gray-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex items-center justify-between text-xs font-mono text-gray-400">
            <span>Step {currentStep} of {totalSteps}</span>
            <span className="text-red-400 font-bold">
              {Math.round((currentStep / totalSteps) * 100)}% Completed
            </span>
          </div>

          {/* Progress Indicator */}
          <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-red-600 h-full transition-all duration-300"
              style={{ width: `${(currentStep / totalSteps) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* STEP 1: Viewing Goal & Favorite Genres */}
        {currentStep === 1 && (
          <div className="space-y-6 animate-in slide-in-from-right-4 duration-200">
            <div>
              <h2 className="text-2xl font-light italic text-white tracking-tight">
                What do you want out of MoodFlix?
              </h2>
              <p className="text-xs text-gray-400 mt-1">
                Select your primary viewing goal and your favorite genres to help us calibrate vector embeddings.
              </p>
            </div>

            {/* Viewing Goal Options */}
            <div className="space-y-2">
              <label className="text-[10px] uppercase font-mono font-bold text-gray-400">Primary Viewing Intent</label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { id: 'relax', title: 'Relax & De-stress', desc: 'Soothe cortisol & tension' },
                  { id: 'discover', title: 'Discover New Picks', desc: 'Expand cinematic horizons' },
                  { id: 'rewatch', title: 'Comfort Classics', desc: 'Warm familiar narratives' },
                ].map((goal) => (
                  <button
                    key={goal.id}
                    type="button"
                    onClick={() => setViewingGoal(goal.id)}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                      viewingGoal === goal.id
                        ? 'bg-red-600/20 border-red-600 text-white'
                        : 'bg-black/40 border-white/10 text-gray-300 hover:border-white/20'
                    }`}
                  >
                    <div className="font-bold text-xs flex items-center justify-between">
                      {goal.title}
                      {viewingGoal === goal.id && <Check className="w-4 h-4 text-red-500" />}
                    </div>
                    <div className="text-[10px] text-gray-400 mt-0.5">{goal.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Favorite Genres Multi-Select */}
            <div className="space-y-2">
              <label className="text-[10px] uppercase font-mono font-bold text-gray-400">
                Favorite Genres (Multi-Select)
              </label>
              <div className="flex flex-wrap gap-2">
                {GENRE_OPTIONS.map((genre) => {
                  const isSelected = favoriteGenres.includes(genre);
                  return (
                    <button
                      key={genre}
                      type="button"
                      onClick={() => toggleGenre(genre, setFavoriteGenres)}
                      className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-all cursor-pointer flex items-center gap-1.5 ${
                        isSelected
                          ? 'bg-red-600 border-red-600 text-white font-bold'
                          : 'bg-black/40 border-white/10 text-gray-300 hover:border-white/20'
                      }`}
                    >
                      {genre}
                      {isSelected && <Check className="w-3.5 h-3.5" />}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: Preferred Languages (All-Language Knowledge) */}
        {currentStep === 2 && (
          <div className="space-y-6 animate-in slide-in-from-right-4 duration-200">
            <div>
              <h2 className="text-2xl font-light italic text-white tracking-tight flex items-center gap-2">
                <Languages className="w-6 h-6 text-red-500" />
                Any languages you'd love to see more of?
              </h2>
              <p className="text-xs text-gray-400 mt-1">
                MoodFlix contains all-language movie knowledge. Select all languages you are open to exploring. Non-selected languages may still be recommended if they strongly match your emotional state!
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {LANGUAGE_OPTIONS.map((lang) => {
                const isSelected = preferredLanguages.includes(lang.code);
                return (
                  <button
                    key={lang.code}
                    type="button"
                    onClick={() => toggleLanguage(lang.code)}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-red-600/20 border-red-600 text-white'
                        : 'bg-black/40 border-white/10 text-gray-300 hover:border-white/20'
                    }`}
                  >
                    <div>
                      <div className="font-bold text-xs">{lang.label}</div>
                      <div className="text-[10px] text-gray-400 uppercase font-mono mt-0.5">ISO Code: {lang.code}</div>
                    </div>
                    <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${isSelected ? 'bg-red-600 border-red-600 text-white' : 'border-white/20'}`}>
                      {isSelected && <Check className="w-3 h-3" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* STEP 3: Disliked Genres & Content Ratings */}
        {currentStep === 3 && (
          <div className="space-y-6 animate-in slide-in-from-right-4 duration-200">
            <div>
              <h2 className="text-2xl font-light italic text-white tracking-tight flex items-center gap-2">
                <Ban className="w-6 h-6 text-red-500" />
                Anything you'd rather avoid?
              </h2>
              <p className="text-xs text-gray-400 mt-1">
                Set boundaries so our hybrid vector ranker penalizes themes you don't enjoy.
              </p>
            </div>

            {/* Disliked Genres */}
            <div className="space-y-2">
              <label className="text-[10px] uppercase font-mono font-bold text-gray-400">
                Disliked Genres to Deprioritize
              </label>
              <div className="flex flex-wrap gap-2">
                {GENRE_OPTIONS.map((genre) => {
                  const isSelected = dislikedGenres.includes(genre);
                  return (
                    <button
                      key={genre}
                      type="button"
                      onClick={() => toggleGenre(genre, setDislikedGenres)}
                      className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-all cursor-pointer flex items-center gap-1.5 ${
                        isSelected
                          ? 'bg-amber-600/30 border-amber-500 text-amber-300 font-bold'
                          : 'bg-black/40 border-white/10 text-gray-300 hover:border-white/20'
                      }`}
                    >
                      {genre}
                      {isSelected && <X className="w-3.5 h-3.5" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Content Rating Limit */}
            <div className="space-y-2">
              <label className="text-[10px] uppercase font-mono font-bold text-gray-400">Content Maturity Threshold</label>
              <div className="grid grid-cols-3 gap-3">
                {['PG', 'PG-13', 'R'].map((rating) => (
                  <button
                    key={rating}
                    type="button"
                    onClick={() => setContentRatingLimit(rating)}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer font-bold text-xs ${
                      contentRatingLimit === rating
                        ? 'bg-red-600/20 border-red-600 text-white'
                        : 'bg-black/40 border-white/10 text-gray-400 hover:border-white/20'
                    }`}
                  >
                    Max {rating}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* STEP 4: Admin Specific Options (If Role === Admin) */}
        {currentStep === 4 && isAdmin && (
          <div className="space-y-6 animate-in slide-in-from-right-4 duration-200">
            <div>
              <h2 className="text-2xl font-light italic text-white tracking-tight flex items-center gap-2">
                <ShieldCheck className="w-6 h-6 text-red-500" />
                Admin Architecture Configurations
              </h2>
              <p className="text-xs text-gray-400 mt-1">
                Since you hold an Admin role, configure your default catalog ingestion regional focus and dashboard links.
              </p>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] uppercase font-mono font-bold text-gray-400">Default Catalog Region Focus</label>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { id: 'global', label: 'Global Cinema (All Languages)' },
                  { id: 'regional', label: 'Regional Focus (Selected Preferred)' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setAdminCatalogRegionFocus(item.id)}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                      adminCatalogRegionFocus === item.id
                        ? 'bg-red-600/20 border-red-600 text-white'
                        : 'bg-black/40 border-white/10 text-gray-400 hover:border-white/20'
                    }`}
                  >
                    <div className="font-bold text-xs">{item.label}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Footer Navigation Buttons */}
        <div className="pt-4 border-t border-white/10 flex items-center justify-between">
          <button
            type="button"
            onClick={handleBack}
            disabled={currentStep === 1}
            className="px-4 py-2.5 bg-transparent border border-white/10 text-gray-400 hover:text-white rounded-xl transition-colors text-xs font-bold uppercase tracking-wider cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
          >
            Back
          </button>

          <button
            type="button"
            onClick={handleNext}
            disabled={isSubmitting}
            className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold uppercase text-xs tracking-widest rounded-xl transition-all shadow-lg shadow-red-600/30 flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isSubmitting ? (
              'Saving Preferences...'
            ) : currentStep === totalSteps ? (
              <>
                Complete & Launch
                <CheckCircle2 className="w-4 h-4" />
              </>
            ) : (
              <>
                Next Step
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
