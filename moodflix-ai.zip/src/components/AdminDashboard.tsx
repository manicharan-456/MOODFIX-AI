import React, { useState, useEffect } from 'react';
import { ShieldCheck, Cpu, Users, Database, RefreshCw, Zap, CheckCircle, AlertTriangle, UserPlus, Globe } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

interface AdminUserData {
  id: string;
  email: string;
  displayName: string;
  role: 'user' | 'admin';
  subscriptionTier: string;
  lastLoginAt: string;
  onboardingCompleted: boolean;
}

interface AdminDashboardData {
  totalUsers: number;
  users: AdminUserData[];
  catalogStats: {
    totalCatalogMovies: number;
    incompleteDescriptionsCount: number;
    languagesCovered: string[];
  };
}

export const AdminDashboard: React.FC = () => {
  const { accessToken } = useAuth();
  const [data, setData] = useState<AdminDashboardData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [promoteEmail, setPromoteEmail] = useState<string>('');
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const fetchAdminData = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/admin/users', {
        headers: { Authorization: `Bearer ${accessToken || 'jwt_access_usr_alex_rivera'}` },
      });
      if (res.ok) {
        const result = await res.json();
        setData(result);
      }
    } catch (err) {
      console.error('Failed to fetch admin data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  const handleTriggerSync = async () => {
    setIsSyncing(true);
    try {
      const res = await fetch('/api/admin/ingestion-sync', {
        method: 'POST',
        headers: { Authorization: `Bearer ${accessToken || 'jwt_access_usr_alex_rivera'}` },
      });
      if (res.ok) {
        setActionMessage('Catalog ingestion & FAISS embedding sync triggered successfully!');
        await fetchAdminData();
      }
    } catch (err) {
      console.error('Ingestion sync failed:', err);
    } finally {
      setIsSyncing(false);
    }
  };

  const handlePromoteUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoteEmail.trim()) return;

    try {
      const res = await fetch('/api/admin/promote-user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${accessToken || 'jwt_access_usr_alex_rivera'}`,
        },
        body: JSON.stringify({ targetEmail: promoteEmail }),
      });
      const result = await res.json();
      if (res.ok) {
        setActionMessage(result.message);
        setPromoteEmail('');
        await fetchAdminData();
      } else {
        setActionMessage(result.error || 'Failed to promote user');
      }
    } catch (err) {
      setActionMessage('Error promoting user');
    }
  };

  if (isLoading) {
    return (
      <div className="py-20 text-center space-y-4">
        <div className="w-10 h-10 border-2 border-red-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
        <p className="text-xs text-gray-400 uppercase font-mono tracking-widest">
          Loading Admin Control Plane...
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="bg-[#111]/80 backdrop-blur-2xl border border-white/10 p-6 md:p-8 rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600/20 text-red-400 border border-red-600/30 text-[10px] uppercase font-bold tracking-widest mb-2">
            <ShieldCheck className="w-3.5 h-3.5" />
            Admin Operations Dashboard
          </div>
          <h1 className="text-2xl md:text-3xl font-light italic text-white tracking-tight">
            System Catalog, Pipeline & User Controls
          </h1>
          <p className="text-xs text-gray-400 mt-1 max-w-xl">
            Monitor all-language movie catalog completeness, FAISS vector embeddings, and registered user role access.
          </p>
        </div>

        <button
          onClick={handleTriggerSync}
          disabled={isSyncing}
          className="px-5 py-3 bg-red-600 hover:bg-red-700 text-white font-bold uppercase text-xs tracking-widest rounded-xl transition-all shadow-lg shadow-red-600/30 flex items-center gap-2 cursor-pointer disabled:opacity-50 shrink-0"
        >
          {isSyncing ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              Syncing Catalog & FAISS Vectors...
            </>
          ) : (
            <>
              <Zap className="w-4 h-4" />
              Run Catalog Ingestion Sync
            </>
          )}
        </button>
      </div>

      {/* Action Notification */}
      {actionMessage && (
        <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono flex items-center justify-between">
          <span className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4" />
            {actionMessage}
          </span>
          <button onClick={() => setActionMessage(null)} className="text-gray-400 hover:text-white text-xs">
            Dismiss
          </button>
        </div>
      )}

      {/* Catalog & Pipeline Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-[#111]/80 backdrop-blur-xl border border-white/10 p-5 rounded-2xl">
          <span className="text-[10px] uppercase text-gray-400 font-bold block mb-1">Total Movies in Catalog</span>
          <span className="text-3xl font-black text-white">{data?.catalogStats.totalCatalogMovies}</span>
          <span className="text-[10px] text-gray-500 block mt-1">All-language coverage</span>
        </div>

        <div className="bg-[#111]/80 backdrop-blur-xl border border-white/10 p-5 rounded-2xl">
          <span className="text-[10px] uppercase text-gray-400 font-bold block mb-1">Incomplete Descriptions</span>
          <span className="text-3xl font-black text-emerald-400">{data?.catalogStats.incompleteDescriptionsCount || 0}</span>
          <span className="text-[10px] text-gray-500 block mt-1">Fallback pass active</span>
        </div>

        <div className="bg-[#111]/80 backdrop-blur-xl border border-white/10 p-5 rounded-2xl">
          <span className="text-[10px] uppercase text-gray-400 font-bold block mb-1">Original Languages</span>
          <span className="text-3xl font-black text-red-500">{data?.catalogStats.languagesCovered.length}</span>
          <span className="text-[10px] text-gray-500 block mt-1 font-mono uppercase">
            {data?.catalogStats.languagesCovered.slice(0, 5).join(', ')}
          </span>
        </div>

        <div className="bg-[#111]/80 backdrop-blur-xl border border-white/10 p-5 rounded-2xl">
          <span className="text-[10px] uppercase text-gray-400 font-bold block mb-1">Registered Users</span>
          <span className="text-3xl font-black text-amber-400">{data?.totalUsers}</span>
          <span className="text-[10px] text-gray-500 block mt-1">Active auth accounts</span>
        </div>
      </div>

      {/* Promote User Form */}
      <div className="bg-[#111]/80 backdrop-blur-xl border border-white/10 p-6 rounded-2xl space-y-4">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <UserPlus className="w-4 h-4 text-red-500" />
          Safe Admin Role Promotion
        </h3>
        <p className="text-xs text-gray-400">
          Promote an existing registered user account to Admin status.
        </p>

        <form onSubmit={handlePromoteUser} className="flex gap-3 max-w-md">
          <input
            type="email"
            value={promoteEmail}
            onChange={(e) => setPromoteEmail(e.target.value)}
            placeholder="user@example.com"
            className="flex-1 bg-black/60 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-red-600"
          />
          <button
            type="submit"
            className="px-4 py-2.5 bg-white text-black hover:bg-gray-200 font-bold uppercase text-xs tracking-wider rounded-xl transition-colors cursor-pointer shrink-0"
          >
            Promote to Admin
          </button>
        </form>
      </div>

      {/* Registered Users Table */}
      <div className="bg-[#111]/80 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden p-6 space-y-4">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <Users className="w-4 h-4 text-red-500" />
          Registered Users & Roles Directory
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-gray-300">
            <thead className="bg-white/5 text-[10px] uppercase font-mono text-gray-400">
              <tr>
                <th className="p-3">User</th>
                <th className="p-3">Role</th>
                <th className="p-3">Subscription</th>
                <th className="p-3">Onboarding</th>
                <th className="p-3">Last Login</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {data?.users.map((u) => (
                <tr key={u.id} className="hover:bg-white/5 transition-colors">
                  <td className="p-3">
                    <div className="font-bold text-white">{u.displayName}</div>
                    <div className="text-[10px] text-gray-500 font-mono">{u.email}</div>
                  </td>
                  <td className="p-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase font-bold ${
                        u.role === 'admin'
                          ? 'bg-red-600/20 text-red-400 border border-red-600/30'
                          : 'bg-white/10 text-gray-300'
                      }`}
                    >
                      {u.role}
                    </span>
                  </td>
                  <td className="p-3 capitalize text-gray-300">{u.subscriptionTier}</td>
                  <td className="p-3 font-mono text-[11px]">
                    {u.onboardingCompleted ? (
                      <span className="text-emerald-400 flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" /> Completed
                      </span>
                    ) : (
                      <span className="text-amber-400">Pending</span>
                    )}
                  </td>
                  <td className="p-3 text-[10px] font-mono text-gray-400">
                    {new Date(u.lastLoginAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
