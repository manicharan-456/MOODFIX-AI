import React from 'react';
import { Movie, WatchHistoryItem } from '../types';
import { Bookmark, Clock, Trash2, Play, Lock, UserCheck } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

interface WatchlistAndHistoryProps {
  mode: 'watchlist' | 'history';
  watchlist: Movie[];
  onRemoveFromWatchlist: (movie: Movie) => void;
  onSelectMovie: (movie: Movie) => void;
  history: WatchHistoryItem[];
  onClearHistory: () => void;
}

export const WatchlistAndHistory: React.FC<WatchlistAndHistoryProps> = ({
  mode,
  watchlist,
  onRemoveFromWatchlist,
  onSelectMovie,
  history,
  onClearHistory,
}) => {
  const { user, isAuthenticated, openAuthModal } = useAuth();

  if (!isAuthenticated) {
    return (
      <div className="max-w-xl mx-auto my-12 bg-[#111]/80 backdrop-blur-2xl border border-white/10 rounded-2xl p-8 text-center space-y-4">
        <div className="w-12 h-12 rounded-full bg-red-600/20 border border-red-600/40 text-red-400 flex items-center justify-center mx-auto">
          <Lock className="w-6 h-6" />
        </div>
        <h2 className="text-xl font-light italic text-white uppercase tracking-tight">
          Authentication Required
        </h2>
        <p className="text-xs text-gray-400 max-w-sm mx-auto leading-relaxed">
          Please sign in to your MoodFlix account to view and manage your personalized {mode === 'watchlist' ? 'Saved Watchlist' : 'Mood History'} scoped to your profile.
        </p>
        <button
          onClick={() => openAuthModal('login')}
          className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold uppercase text-xs tracking-widest rounded-xl transition-all shadow-lg shadow-red-600/30 cursor-pointer"
        >
          Sign In Now
        </button>
      </div>
    );
  }

  if (mode === 'watchlist') {
    return (
      <div className="space-y-6 max-w-6xl mx-auto">
        <div className="flex justify-between items-center bg-[#111]/80 backdrop-blur-2xl border border-white/10 p-6 rounded-2xl">
          <div>
            <div className="flex items-center gap-2 text-[10px] uppercase font-mono text-emerald-400 font-bold mb-1">
              <UserCheck className="w-3.5 h-3.5" />
              Scoped to {user?.displayName} ({user?.email})
            </div>
            <h1 className="text-xl md:text-2xl font-bold uppercase tracking-tight text-white flex items-center gap-2">
              <Bookmark className="w-5 h-5 text-red-500" />
              My Saved Watchlist
            </h1>
            <p className="text-xs text-gray-400 mt-1">
              {watchlist.length} {watchlist.length === 1 ? 'title' : 'titles'} queued for your upcoming mood sessions
            </p>
          </div>
        </div>

        {watchlist.length === 0 ? (
          <div className="text-center py-20 bg-[#111]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-8">
            <Bookmark className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <h3 className="text-base font-bold text-white uppercase tracking-wider mb-1">
              Your Watchlist is Empty
            </h3>
            <p className="text-xs text-gray-500 max-w-md mx-auto">
              Recalibrate your mood on the Discover page and click "Add to Watchlist" to save movies here for quick access.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {watchlist.map((movie) => (
              <div
                key={movie.id}
                className="bg-[#111]/80 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden group hover:border-white/20 transition-all flex flex-col justify-between"
              >
                <div className="relative h-48 overflow-hidden cursor-pointer" onClick={() => onSelectMovie(movie)}>
                  <img
                    src={movie.backdropUrl || movie.posterUrl}
                    alt={movie.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 right-4 z-10">
                    <h3 className="text-lg font-light italic text-white group-hover:text-red-400 transition-colors">
                      {movie.title}
                    </h3>
                    <div className="text-xs text-gray-300 font-medium mt-0.5">
                      {movie.year} • {movie.runtime}
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-black/40 space-y-3 flex-1 flex flex-col justify-between">
                  <p className="text-xs text-gray-400 line-clamp-2 italic font-light">
                    "{movie.overview}"
                  </p>

                  <div className="flex gap-2 pt-2 border-t border-white/10">
                    <button
                      onClick={() => onSelectMovie(movie)}
                      className="flex-1 py-2 bg-white hover:bg-gray-200 text-black font-bold uppercase text-[10px] tracking-widest rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Play className="w-3 h-3 fill-black" />
                      View
                    </button>
                    <button
                      onClick={() => onRemoveFromWatchlist(movie)}
                      className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-600/10 border border-white/10 hover:border-red-600/30 rounded-lg transition-colors cursor-pointer"
                      title="Remove from Watchlist"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <div className="flex justify-between items-center bg-[#111]/80 backdrop-blur-2xl border border-white/10 p-6 rounded-2xl">
        <div>
          <div className="flex items-center gap-2 text-[10px] uppercase font-mono text-emerald-400 font-bold mb-1">
            <UserCheck className="w-3.5 h-3.5" />
            Scoped to {user?.displayName} ({user?.email})
          </div>
          <h1 className="text-xl md:text-2xl font-bold uppercase tracking-tight text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-red-500" />
            Mood Recalibration History
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            Timeline of past emotional state queries and corresponding movie inferences
          </p>
        </div>

        {history.length > 0 && (
          <button
            onClick={onClearHistory}
            className="text-xs text-gray-400 hover:text-red-400 border border-white/10 px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear Log
          </button>
        )}
      </div>

      {history.length === 0 ? (
        <div className="text-center py-20 bg-[#111]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-8">
          <Clock className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <h3 className="text-base font-bold text-white uppercase tracking-wider mb-1">
            No Past Mood Queries Yet
          </h3>
          <p className="text-xs text-gray-500 max-w-md mx-auto">
            Your mood recalibrations will be logged here so you can revisit recommendations matching specific emotional states.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {history.map((item) => (
            <div
              key={item.id}
              className="bg-[#111]/80 backdrop-blur-xl border border-white/10 p-5 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 hover:border-white/20 transition-all"
            >
              <div className="flex-1 min-w-0">
                <div className="text-[10px] uppercase font-mono text-red-500 font-bold mb-1">
                  Logged on {item.watchedAt}
                </div>
                <div className="text-sm font-light italic text-gray-200 mb-2">
                  "{item.userMoodPrompt}"
                </div>
                <div className="flex items-center gap-2 text-xs font-medium text-gray-400">
                  <span>Recommended:</span>
                  <span className="text-white font-bold">{item.movie.title}</span>
                  <span>({item.movie.year})</span>
                </div>
              </div>

              <button
                onClick={() => onSelectMovie(item.movie)}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 border border-white/10 text-white font-bold uppercase text-[10px] tracking-widest rounded-lg transition-colors cursor-pointer self-start md:self-auto shrink-0"
              >
                Revisit Movie
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
